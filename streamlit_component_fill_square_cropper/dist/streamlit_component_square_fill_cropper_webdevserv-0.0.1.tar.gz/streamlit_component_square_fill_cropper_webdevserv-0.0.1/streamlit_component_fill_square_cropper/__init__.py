import streamlit.components.v1 as components
component_zero = components.declare_component(
    name='fill_square_cropper',
    path='./streamlit_component_fill_square_cropper'
)